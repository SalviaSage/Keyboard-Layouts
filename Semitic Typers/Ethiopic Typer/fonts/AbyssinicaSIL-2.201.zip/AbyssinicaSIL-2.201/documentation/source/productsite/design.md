
Abyssinica SIL is based on Ethiopic calligraphic traditions. 

One font from this typeface family is included in the *Abyssinica SIL* release (no bold or italic version available or planned):

* Abyssinica SIL Regular


## Type Samples

Type samples showing some of the inventory of glyphs can be found here: 
[Abyssinica SIL Type Sample](sample).

A sample from one page is shown below. 

<img class='fullsize' alt='Abyssinica SIL Sample - Ethiopic syllables' src='https://software.sil.org/abyssinica/wp-content/uploads/sites/26/2019/09/AbyssinicaTypeSamplev2.png' />
[caption]<em>Abyssinica SIL Sample - Ethiopic syllables</em>[/caption]

