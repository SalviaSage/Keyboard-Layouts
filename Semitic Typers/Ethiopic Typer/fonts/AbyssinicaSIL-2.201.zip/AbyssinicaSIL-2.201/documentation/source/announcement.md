---
title: Abyssinica SIL - Announcement
fontversion: 2.201
---

This is a minor release. Changes for this version include the following:

- Fixed bug in TypeTuner support for cv46 tswa alternate

#### Known issues

- There are no known issues.

Download the release packages from the [Download Page](https://software.sil.org/abyssinica/download/).
