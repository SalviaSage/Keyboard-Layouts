Arabic-Persian Typer;

Fully types Arabic primarily and Persian and Ottoman Turkish secondarily.
Supports typing the Persian and Ottoman Turkish forms of the letters and numbers by hitting the scroll lock (Kana lock) key.
This changes the shape of some of the letters and the numbers on the numpad.

Some Urdu Specific letters can be typed by pressing AltGr + Letters.

The top row numbers have been changed with diacritics.
Those diacritics are as follows:

1 shadda
2 sukun
3 small high dotless head of khah (sukun variant)
4 madda
5 superscript alef
6 subscript alef
7 fathatan
8 dammatan
9 kasratan
0 combining hamza above, combining hamza below

The hyphen key has the hyphen, but also has the Arabic tatweel character which is an empty lengthener line.