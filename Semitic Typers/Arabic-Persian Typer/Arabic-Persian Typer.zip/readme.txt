Arabic-Persian Typer;

Fully types Arabic primarily and Persian and Ottoman Turkish secondarily.
Supports typing the Persian and Ottoman Turkish forms of the letters and numbers by hitting the scroll lock (Kana lock) key.
This changes the shape of some of the letters and the numbers on the numpad.

Alef waslah can be typed with Ctrl + Shift + Alef.
Alef maqsurah can be typed with AltGr + Alef.
Some Urdu Specific letters can be typed by pressing AltGr + Letters (in Kana mode).

The top row numbers have been changed with diacritics.
Those diacritics are as follows:

1 tatweel
2 shadda
3 sukun
4 madda
5 superscript alef
6 subscript alef
7 fathatan
8 dammatan
9 kasratan
0 combining hamza above, combining hamza below
