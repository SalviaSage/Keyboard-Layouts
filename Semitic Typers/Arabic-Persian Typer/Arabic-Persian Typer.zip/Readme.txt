Arabic-Persian typer;

Fully types Arabic, Persian and Ottoman Turkish.