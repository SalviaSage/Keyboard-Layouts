Persian typer;

Fully types Persian and Ottoman Turkish primarily and Arabic secondarily.
Supports typing the Arabic forms of the letters by hitting the scroll lock key.
This changes some of the letters and the numbers in the numpad.
