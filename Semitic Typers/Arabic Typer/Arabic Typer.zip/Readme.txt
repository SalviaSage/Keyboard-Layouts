Arabic typer;

Fully types Arabic primarily and Persian and Ottoman Turkish secondarily.
Supports typing the Persian and Ottoman Turkish forms of the letters by hitting the scroll lock key.
This changes some of the letters and the numbers in the numpad.
