Urdu typer;

Fully types Urdu which in turn is very similar to Persian.
Supports typing the Arabic forms of the letters by hitting the scroll lock key.
This changes some of the letters and the numbers in the numpad.
