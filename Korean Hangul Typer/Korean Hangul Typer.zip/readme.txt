Korean Hangul Typer;

— Contains double letter variations of some consonants by pressing shift and consonant letter.
— Contains vowel variants when pressing Shift + vowel letter.

The letter "ieung" (ᄋ) is located at the "Q" position.
This letter is used before vowel letters to form vowels at the start of syllables.
That is, it is an orthographic error to use only the vowel letters at the start of syllables.
For example, first type  (ᄋ) and then type  (ᅲ) to get (요).

All consonants come in two formats, the "start of syllable" (top) format and the "end of syllable" (bottom) format.
If the consonant is at the end of a syllable, we have to press caps lock + consonant letter to get the syllable final form of the consonant.

For example, to type (한국);
Press (H), press (A), press Caps Lock + (N)
	make sure caps lock is turned off.
Press (G), press (U), press Caps Lock + (G)

The typer helper program makes it so that when we press and hold the consonant letters it moves these letters to the bottom of the syllable block.
This makes it so that we don't have to press caps lock to type syllable final consonants.

— There are two obsolete Korean diacritical marks located at AltGr+(=), and Shift+AltGr+(=) keys.

Hangul jungseong filler (U+1160) located at Ctrl+Space.
	This character is supposed to be used AFTER consonant letters to make them standalone (non-syllable) letters.

Hangul choseong filler (U+115F) located at Shift+Ctrl+Space.
	This character is supposed to be used BEFORE vowel letters to make them standalone (non-syllable) letters.

The keyboard layout does contain the four obsolete letters.
They are typed by pressing AltGr+Letter.

There are also some Hanja Chinese characters for numerals on the numpad that are typed by pressing AltGr+NumpadKey.

	ISSUES WITH CHARACTER JOINING:
In certain less developed text fields and platforms the Korean characters will not correctly join each other and write as separate letters.
For example:(하ᄂ구ᄀ) instead of (한국).

This practically makes the alphabet unusable in that scenario.
I saw during testing that the more developed platforms support character joining appropriately.
However, notepad.exe and notepad++.exe doesn't support it.

