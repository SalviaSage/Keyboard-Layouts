Turkish Typer;

Also types the Kurdish Hawar alphabet and the Azerbaijani alphabet.

You can type the circumflex accent on top of vowel letters with the backslash key (\).
If you want to preserve the dot on top of the letter i and add the circumflex accent;
type the dotless i (ı) and then press shift+backslash key.

Types:
	Turkish Latin Alphabet
	Kurdish Hawar Latin Alphabet
	Azerbaijani Latin Alphabet

	Common Turkic Alphabet 2024 (with RightAlt+Letter)
	Turkmen Latin Alphabet (with RightAlt+Letter)
	Most Turkic Latin Alphabets (with RightAlt+Letter)
