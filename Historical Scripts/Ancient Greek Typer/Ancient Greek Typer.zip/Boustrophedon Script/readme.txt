Boustrophedon Script;

A script that helps in the automation of writing in Boustrophedon style.

What it does:
Every time the Control+Enter key is pressed, caps lock is turned on.
Every time Enter is pressed, caps lock is turned off.

The idea is that, the typist will press control+enter or shift+enter and also press control+rightshift to type in "retrograde" mode.
Then the typist will hit the enter button and also press also press control+leftshift to type in regular or "prograde" mode.

This itself is not enough to type in "retrograde" mode because the typist will also have to enter the right-to-left override (U+202E) character at the start of the new line.
The insertion of that character however, can be placed in the computer program for the keyboard layout at the control+enter and shift+enter positions.

-----
