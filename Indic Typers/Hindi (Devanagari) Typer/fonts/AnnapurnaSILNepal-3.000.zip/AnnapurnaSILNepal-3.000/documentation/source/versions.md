---
title: Annapurna SIL - Versions and Changes
fontversion: 3.000
---

## Announcement list

If you would like stay informed of updates to Annapurna SIL and other SIL fonts, please subscribe to the [SIL Font News Announcement List](https://groups.google.com/a/groups.sil.org/forum/#!forum/sil-font-news). For more information see [About](about.md).

## Current versions

The latest version of the fonts is always available from the [Annapurna SIL download page](https://software.sil.org/annapurna/download/) as a .zip archive for all major platforms.

Annapurna SIL is also available through the [TypeTuner Web](https://scripts.sil.org/ttw/fonts2go.cgi) service, which allows you to choose among the smart font features and download a font with those features preset. This enables them to work in many applications that do not make use of OpenType Stylistic Sets or Character Variants.

## Previous versions

Previous versions remain available from our [Annapurna SIL download page](https://software.sil.org/annapurna/download/).

## Change history

A detailed list of changes for each version of the fonts is on the [Version history page](history.md).
