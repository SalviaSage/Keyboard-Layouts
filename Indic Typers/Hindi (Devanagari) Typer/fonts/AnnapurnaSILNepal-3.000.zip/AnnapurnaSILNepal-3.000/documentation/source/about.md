---
title: Annapurna SIL - About
fontversion: 3.000
---

## About this project

This project is intended to provide a free and open font family for all current languages and writing systems that use the Devanagari script. It also includes a large set of ligatures useful for linguistics and literacy work. Smart font routines automatically produce these ligatures. In addition, user-selectable features are included to choose variant characters or ligatures. 

For more information on the visual characteristics of the font family see [Design](design.md).

For a complete list of characters included in Annapurna, see Character Set Support.

For variant glyphs and features supported in Annapurna, see [Font Features](features.md).

## Future plans

These fonts are actively maintained and improved, and recent changes to their development process will enable more frequent releases.

The highest priorities for future additions and enhancements are mainly driven by:

- New additions to [The Unicode Standard](https://unicode.org/)
- Requests from language communities using the fonts
- Needs of the linguistic and academic community

Please send us your requests using the [form on the font website](https://software.sil.org/annapurna/about/contact/). If you are interested in helping us make the fonts better, see the [Developer](developer.md) page.

## Announcement list

If you wish to receive announcements about updates to any of our SIL fonts, please subscribe to our [SIL Font News Announcement List](https://groups.google.com/a/groups.sil.org/forum/#!forum/sil-font-news). This is an announcement-only list with messages approximately once a month. It does not allow any discussion.

You can subscribe using either of the two following options.

- If you use a Google profile and join the group, you will be able to access the group and control your subscription and notification options with a web browser. Make sure you are logged in to your Google profile and go to the [SIL Font News Google Group](https://groups.google.com/a/groups.sil.org/forum/#!forum/sil-font-news). Click on **Join group**.

- If you would rather not use a Google profile, you can subscribe any email address by sending a message to [sil-font-news+subscribe@groups.sil.org](mailto:sil-font-news+subscribe@groups.sil.org) and following the instructions you get in the confirmation message.

## Supporting the project

These fonts are provided at no cost; however, they are expensive to produce and maintain. Please consider donating to SIL’s font development efforts to support future development. Go to the [WSTech donation page](https://give.sil.org/campaign/725115/donate). **Thank you!** 

## About SIL Global

[SIL Global](https://www.sil.org/) is a community of local organizations that walk alongside minority language communities to help them know God and use their languages to flourish. 

As of 2025, we are active partners with 1,572 active language projects in 119 countries. These projects impact more than 950+ million people. SIL’s work brings together more than 4,200 staff and volunteers who work alongside thousands more local partners worldwide. Our services are available without regard to religious belief, political ideology, gender, race or ethnic background.

Our Vision: We long to see people flourishing in community using the languages they value most. 

Our Mission: Inspired by God’s love, we advocate, build capacity, and work with local communities to apply language expertise that advances meaningful development, education, and engagement with Scripture.

[SIL Language Technology](https://software.sil.org/) supports these activities by developing [software](https://software.sil.org/software-products/), [fonts](https://software.sil.org/fonts/), and [keyboard technologies](https://keyman.com/).
