Punjabi (Gurmukhi) Typer;

